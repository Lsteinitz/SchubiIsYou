package com.example.schubi_is_you;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
